# Mustdohr Website Assistant

Install this plugin from **Plugins → Add New → Upload Plugin** and upload the ZIP package.

## Integration points

- REST search endpoint: `/wp-json/mustdohr-search/v1/ask`
- REST AI endpoint: `/wp-json/mustdohr-search/v1/ai`
- Both endpoints accept `message` and optional `lang`.
- `mdh_chatbot_supported_languages` filters the allowed language codes.
- `mdh_chatbot_language` filters the selected language.
- `mdh_chatbot_storage_event` filters each event before storage.
- `mdh_chatbot_storage_handler` can return a callable database adapter.
- `mdh_chatbot_event` fires for each received question.

The plugin does not create a database table by default. A separate host plugin can attach a storage adapter without changing the chatbot code.

Example adapter:

```php
add_filter('mdh_chatbot_storage_handler', function () {
    return function ($event) {
        // Save $event to your own table, API, or database service.
    };
});
```
